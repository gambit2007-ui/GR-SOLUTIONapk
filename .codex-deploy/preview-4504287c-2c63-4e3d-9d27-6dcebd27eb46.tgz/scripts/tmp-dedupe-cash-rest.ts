type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

type FirestoreDocumentRow = {
  document?: {
    name?: string;
    fields?: Record<string, FirestoreValue>;
  };
};

type MovementDoc = {
  id: string;
  path: string;
  type: string;
  amount: number;
  description: string;
  date: string;
  loanId?: string;
  createdByEmail?: string;
};

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const round2 = (value: number) => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) {
      obj[k] = decodeValue(v);
    }
    return obj;
  }
  return undefined;
};

const normalizeText = (value: unknown) =>
  String(value ?? '')
    .trim()
    .toUpperCase();

const normalizeEmail = (value: unknown) =>
  String(value ?? '')
    .trim()
    .toLowerCase();

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const parseArgs = () => {
  const args = new Map<string, string>();
  let apply = false;
  for (const token of process.argv.slice(2)) {
    if (token === '--apply') {
      apply = true;
      continue;
    }
    const [key, ...valueParts] = token.split('=');
    if (!key?.startsWith('--') || valueParts.length === 0) continue;
    args.set(key.slice(2), valueParts.join('=').trim());
  }

  const description = normalizeText(args.get('description'));
  const createdByEmail = normalizeEmail(args.get('created-by-email'));
  const datePrefix = String(args.get('date-prefix') ?? '').trim();
  const amount = round2(Number(String(args.get('amount') ?? '').replace(',', '.')));

  if (!description) throw new Error('Use --description="..."');
  if (!createdByEmail) throw new Error('Use --created-by-email="..."');
  if (!datePrefix) throw new Error('Use --date-prefix=YYYY-MM-DD');
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('Use --amount=123.45');

  return { apply, description, createdByEmail, datePrefix, amount };
};

const fetchCollection = async (idToken: string, collectionId: string) => {
  const response = await fetch(`${BASE_URL}:runQuery`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId }],
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`runQuery ${collectionId} failed: ${response.status} ${text}`);
  }

  return (await response.json()) as FirestoreDocumentRow[];
};

const parseMovementDoc = (row: FirestoreDocumentRow): MovementDoc | null => {
  const doc = row.document;
  if (!doc?.fields || !doc.name) return null;
  const id = doc.name.split('/').pop() ?? '';
  const payload: JsonRecord = {};
  for (const [key, value] of Object.entries(doc.fields)) {
    payload[key] = decodeValue(value);
  }

  return {
    id,
    path: doc.name.replace(/^projects\/[^/]+\/databases\/\(default\)\/documents\//, ''),
    type: normalizeText(payload.type || 'ENTRADA') || 'ENTRADA',
    amount: round2(Math.abs(Number(payload.amount ?? payload.value ?? 0))),
    description: normalizeText(payload.description || 'MOVIMENTACAO') || 'MOVIMENTACAO',
    date: String(payload.date ?? ''),
    loanId: String(payload.loanId ?? '').trim() || undefined,
    createdByEmail: normalizeEmail(payload.createdByEmail) || undefined,
  };
};

const resolveCashDelta = (movement: MovementDoc) => {
  if (movement.type === 'APORTE' || movement.type === 'PAGAMENTO' || movement.type === 'ENTRADA') {
    return movement.amount;
  }
  return -movement.amount;
};

const sortByDateAsc = (items: MovementDoc[]) =>
  [...items].sort((a, b) => {
    const at = Number.isNaN(new Date(a.date).getTime()) ? 0 : new Date(a.date).getTime();
    const bt = Number.isNaN(new Date(b.date).getTime()) ? 0 : new Date(b.date).getTime();
    if (at !== bt) return at - bt;
    return a.id.localeCompare(b.id);
  });

const patchCashBalance = async (idToken: string, value: number) => {
  const url = `${BASE_URL}/settings/caixa?updateMask.fieldPaths=value&updateMask.fieldPaths=updatedAt`;
  const response = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fields: {
        value: Number.isInteger(value)
          ? { integerValue: String(value) }
          : { doubleValue: value },
        updatedAt: { timestampValue: new Date().toISOString() },
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Patch caixa failed: ${response.status} ${text}`);
  }
};

const run = async () => {
  const criteria = parseArgs();
  const idToken = await getAuthToken();

  const rows = await fetchCollection(idToken, 'cashMovement');
  const movements = rows
    .map(parseMovementDoc)
    .filter((item): item is MovementDoc => item !== null);

  const matches = sortByDateAsc(
    movements.filter((movement) => (
      movement.description === criteria.description &&
      movement.amount === criteria.amount &&
      movement.createdByEmail === criteria.createdByEmail &&
      movement.date.startsWith(criteria.datePrefix)
    )),
  );

  const resultBase = {
    ok: true,
    dryRun: !criteria.apply,
    criteria,
    matchedCount: matches.length,
    keep: matches[0] ?? null,
    remove: matches.slice(1),
  };

  if (!criteria.apply) {
    console.log(JSON.stringify(resultBase, null, 2));
    return;
  }

  if (matches.length < 2) {
    throw new Error('Nenhum duplicado encontrado para aplicar limpeza.');
  }

  const [, ...toRemove] = matches;
  for (const movement of toRemove) {
    const response = await fetch(`${BASE_URL}/${movement.path}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${idToken}`,
      },
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Delete failed for ${movement.id}: ${response.status} ${text}`);
    }
  }

  const remainingRows = await fetchCollection(idToken, 'cashMovement');
  const remainingMovements = remainingRows
    .map(parseMovementDoc)
    .filter((item): item is MovementDoc => item !== null);
  const recalculatedCash = round2(remainingMovements.reduce((sum, movement) => sum + resolveCashDelta(movement), 0));
  await patchCashBalance(idToken, recalculatedCash);

  console.log(JSON.stringify({
    ...resultBase,
    dryRun: false,
    deletedIds: toRemove.map((item) => item.id),
    recalculatedCash,
  }, null, 2));
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
