import { doc, getDoc } from 'firebase/firestore';
import { createFirebaseScriptSession } from './shared/firebaseClient.ts';
import { buildLegacySimpleBreakdown, resolveInstallmentNumber, resolveInstallmentPaidAmount } from '../src/utils/legacyBreakdownMigration.ts';
import type { LegacyInstallmentLike, LegacyLoanLike } from '../src/utils/legacyBreakdownMigration.ts';

const loanId = 'j6lb36r2n';

const round2 = (value: number) => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const run = async () => {
  const s = await createFirebaseScriptSession();
  const snap = await getDoc(doc(s.db, 'loans', loanId));
  if (!snap.exists()) throw new Error('not found');

  const raw = snap.data() as Record<string, unknown>;
  const installments = (Array.isArray(raw.installments) ? raw.installments : []) as LegacyInstallmentLike[];

  const loanLike: LegacyLoanLike = {
    id: loanId,
    amount: Number(raw.amount ?? 0),
    totalToReturn: Number(raw.totalToReturn ?? 0),
    interestRate: Number(raw.interestRate ?? 0),
    interestType: raw.interestType,
    installmentCount: Number(raw.installmentCount ?? 0),
    installmentsCount: Number(raw.installmentsCount ?? 0),
    installments,
  };

  const rows = installments.map((inst, idx) => {
    const number = resolveInstallmentNumber(inst, idx);
    const paid = resolveInstallmentPaidAmount(inst);
    const current = (typeof inst.paymentBreakdown === 'object' && inst.paymentBreakdown !== null)
      ? inst.paymentBreakdown
      : null;
    const recalculated = paid > 0 ? buildLegacySimpleBreakdown(loanLike, inst)?.paymentBreakdown ?? null : null;

    const diff = recalculated && current
      ? {
          principal: round2(Number(recalculated.principalPaid || 0) - Number(current.principalPaid || 0)),
          interest: round2(Number(recalculated.interestPaid || 0) - Number(current.interestPaid || 0)),
          lateFee: round2(Number(recalculated.lateFeePaid || 0) - Number(current.lateFeePaid || 0)),
          total: round2(Number(recalculated.totalPaid || 0) - Number(current.totalPaid || 0)),
        }
      : null;

    return {
      idx,
      number,
      status: inst.status,
      amount: Number((inst as Record<string, unknown>).amount ?? (inst as Record<string, unknown>).value ?? 0),
      paidAmount: paid,
      current,
      recalculated,
      diff,
    };
  });

  console.log(JSON.stringify({
    loanId,
    contractNumber: raw.contractNumber,
    customerName: raw.customerName,
    rows,
  }, null, 2));
};

run().catch((e) => {
  console.error(e instanceof Error ? e.message : String(e));
  process.exit(1);
});
