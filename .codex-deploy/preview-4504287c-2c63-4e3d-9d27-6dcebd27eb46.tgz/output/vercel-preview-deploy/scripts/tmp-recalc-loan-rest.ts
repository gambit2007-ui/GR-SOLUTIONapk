import fs from 'node:fs/promises';
import path from 'node:path';
import {
  classifyLegacyInstallment,
  buildLegacySimpleBreakdown,
  buildLegacyPriceBreakdown,
  resolveInstallmentNumber,
} from '../src/utils/legacyBreakdownMigration.ts';
import type {
  BreakdownMigrationReasonCode,
  LegacyInstallmentLike,
  LegacyLoanLike,
} from '../src/utils/legacyBreakdownMigration.ts';

type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const round2 = (value: number): number => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) {
      obj[k] = decodeValue(v);
    }
    return obj;
  }
  return undefined;
};

const encodeValue = (value: unknown): FirestoreValue => {
  if (value === null || value === undefined) return { nullValue: null };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return { doubleValue: 0 };
    return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
  }
  if (typeof value === 'string') return { stringValue: value };
  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map((entry) => encodeValue(entry)) } };
  }
  if (typeof value === 'object') {
    const fields: Record<string, FirestoreValue> = {};
    for (const [k, v] of Object.entries(value as JsonRecord)) {
      if (v !== undefined) fields[k] = encodeValue(v);
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(value) };
};

const parseArgs = () => {
  const args = new Map<string, string>();
  for (const token of process.argv.slice(2)) {
    const [key, value] = token.split('=');
    if (key?.startsWith('--') && value) args.set(key.slice(2), value);
  }
  return {
    loanId: args.get('loan-id') ?? 'j6lb36r2n',
    includeEstorno: (args.get('include-estorno') ?? 'true').toLowerCase() !== 'false',
    dryRun: (args.get('dry-run') ?? 'false').toLowerCase() === 'true',
    forceOverwriteExisting: (args.get('force-overwrite-existing') ?? 'false').toLowerCase() === 'true',
  };
};

const normalizeBreakdown = (value: unknown): Record<string, number> => {
  const breakdown = typeof value === 'object' && value !== null ? (value as JsonRecord) : {};
  return {
    principalPaid: round2(Number(breakdown.principalPaid ?? 0)),
    interestPaid: round2(Number(breakdown.interestPaid ?? 0)),
    lateFeePaid: round2(Number(breakdown.lateFeePaid ?? 0)),
    serviceFeePaid: round2(Number(breakdown.serviceFeePaid ?? 0)),
    discountApplied: round2(Number(breakdown.discountApplied ?? 0)),
    totalPaid: round2(Number(breakdown.totalPaid ?? 0)),
  };
};

const shouldPersistInstallmentUpdate = (current: JsonRecord, next: JsonRecord): boolean => {
  const currentState = {
    paymentBreakdown: normalizeBreakdown(current.paymentBreakdown),
    breakdownSource: String(current.breakdownSource ?? ''),
    needsFiscalReview: Boolean(current.needsFiscalReview),
    expectedPrincipal:
      current.expectedPrincipal === undefined || current.expectedPrincipal === null
        ? null
        : round2(Number(current.expectedPrincipal)),
    expectedInterest:
      current.expectedInterest === undefined || current.expectedInterest === null
        ? null
        : round2(Number(current.expectedInterest)),
  };

  const nextState = {
    paymentBreakdown: normalizeBreakdown(next.paymentBreakdown),
    breakdownSource: String(next.breakdownSource ?? ''),
    needsFiscalReview: Boolean(next.needsFiscalReview),
    expectedPrincipal:
      next.expectedPrincipal === undefined || next.expectedPrincipal === null
        ? null
        : round2(Number(next.expectedPrincipal)),
    expectedInterest:
      next.expectedInterest === undefined || next.expectedInterest === null
        ? null
        : round2(Number(next.expectedInterest)),
  };

  return JSON.stringify(currentState) !== JSON.stringify(nextState);
};

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const fetchLoan = async (idToken: string, loanId: string) => {
  const response = await fetch(`${BASE_URL}/loans/${loanId}`, {
    headers: { Authorization: `Bearer ${idToken}` },
  });

  if (response.status === 404) return null;
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan fetch failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { name?: string; fields?: Record<string, FirestoreValue> };
  const fields = payload.fields ?? {};
  const decoded: JsonRecord = {};
  for (const [key, value] of Object.entries(fields)) {
    decoded[key] = decodeValue(value);
  }

  return { name: payload.name ?? '', data: decoded };
};

const fetchCashMovements = async (idToken: string, loanId: string): Promise<JsonRecord[]> => {
  const response = await fetch(`${BASE_URL}:runQuery`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: 'cashMovement' }],
        where: {
          fieldFilter: {
            field: { fieldPath: 'loanId' },
            op: 'EQUAL',
            value: { stringValue: loanId },
          },
        },
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Cash movement query failed: ${response.status} ${text}`);
  }

  const rows = (await response.json()) as Array<{ document?: { fields?: Record<string, FirestoreValue> } }>;
  const result: JsonRecord[] = [];

  for (const row of rows) {
    if (!row.document?.fields) continue;
    const decoded: JsonRecord = {};
    for (const [key, value] of Object.entries(row.document.fields)) {
      decoded[key] = decodeValue(value);
    }
    result.push(decoded);
  }

  return result;
};

const buildEstornoLookup = (movements: JsonRecord[]) => {
  const regex = /ESTORNO\s+PARCELA\s+(\d+)/i;
  const installments = new Set<number>();
  let generic = false;

  for (const movement of movements) {
    const type = String(movement.type ?? '').trim().toUpperCase();
    if (type !== 'ESTORNO') continue;

    const description = String(movement.description ?? '');
    const match = description.match(regex);
    if (!match) {
      generic = true;
      continue;
    }

    const number = Number(match[1]);
    if (Number.isFinite(number) && number > 0) installments.add(Math.trunc(number));
    else generic = true;
  }

  return { generic, installments };
};

const applyUpdate = async (idToken: string, loanId: string, installments: unknown[]) => {
  const url = `${BASE_URL}/loans/${loanId}?updateMask.fieldPaths=installments`;
  const response = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fields: {
        installments: encodeValue(installments),
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan update failed: ${response.status} ${text}`);
  }

  return response.json();
};

const run = async () => {
  const { loanId, includeEstorno, dryRun, forceOverwriteExisting } = parseArgs();
  const idToken = await getAuthToken();
  const loan = await fetchLoan(idToken, loanId);

  if (!loan) {
    throw new Error(`Loan not found: ${loanId}`);
  }

  const installmentsRaw = Array.isArray(loan.data.installments) ? loan.data.installments : [];
  const movements = await fetchCashMovements(idToken, loanId);
  const estornoLookup = buildEstornoLookup(movements);

  const loanLike: LegacyLoanLike = {
    id: loanId,
    amount: Number(loan.data.amount ?? 0),
    totalToReturn: Number(loan.data.totalToReturn ?? 0),
    interestRate: Number(loan.data.interestRate ?? 0),
    interestType: loan.data.interestType,
    installmentCount: Number(loan.data.installmentCount ?? 0),
    installmentsCount: Number(loan.data.installmentsCount ?? 0),
    installments: installmentsRaw as LegacyInstallmentLike[],
  };

  const updatedInstallments = installmentsRaw.map((entry) =>
    typeof entry === 'object' && entry !== null ? { ...(entry as JsonRecord) } : ({} as JsonRecord),
  );

  const changed: Array<{
    installmentIndex: number;
    installmentNumber: number | null;
    breakdownSource: string;
    needsFiscalReview: boolean;
    reasonCodes: BreakdownMigrationReasonCode[];
    paymentBreakdown: unknown;
  }> = [];

  (installmentsRaw as LegacyInstallmentLike[]).forEach((installment, index) => {
    const installmentNumber = resolveInstallmentNumber(installment, index);
    const linkedToEstorno =
      estornoLookup.generic || (installmentNumber ? estornoLookup.installments.has(installmentNumber) : false);
    const installmentForClassification: LegacyInstallmentLike = forceOverwriteExisting
      ? {
          ...installment,
          paymentBreakdown: undefined,
        }
      : installment;

    const classification = classifyLegacyInstallment(
      loanLike,
      installmentForClassification,
      index,
      includeEstorno ? false : linkedToEstorno,
    );

    if (classification.category === 'SKIP_ALREADY_HAS_BREAKDOWN') return;
    if (classification.category === 'SKIP_NO_PAYMENT') return;

    let breakdownResult = null;
    if (classification.category === 'MIGRATABLE_SIMPLE') {
      breakdownResult = buildLegacySimpleBreakdown(loanLike, installment);
    } else if (classification.category === 'MIGRATABLE_PRICE') {
      breakdownResult = buildLegacyPriceBreakdown(loanLike, installment, index, true);
    }

    if (!breakdownResult) return;

    if (includeEstorno && linkedToEstorno) {
      breakdownResult = {
        ...breakdownResult,
        needsFiscalReview: true,
        reasonCodes: Array.from(
          new Set<BreakdownMigrationReasonCode>([
            'linked_estorno_detected',
            ...(breakdownResult.reasonCodes ?? []),
          ]),
        ),
      };
    }

    const current = updatedInstallments[index] ?? {};
    const next = {
      ...current,
      paymentBreakdown: breakdownResult.paymentBreakdown,
      breakdownSource: breakdownResult.breakdownSource,
      needsFiscalReview: breakdownResult.needsFiscalReview,
      expectedPrincipal:
        current.expectedPrincipal === undefined || current.expectedPrincipal === null
          ? breakdownResult.expectedPrincipal
          : current.expectedPrincipal,
      expectedInterest:
        current.expectedInterest === undefined || current.expectedInterest === null
          ? breakdownResult.expectedInterest
          : current.expectedInterest,
    };

    if (!shouldPersistInstallmentUpdate(current, next)) {
      return;
    }

    updatedInstallments[index] = next;

    changed.push({
      installmentIndex: index,
      installmentNumber,
      breakdownSource: breakdownResult.breakdownSource,
      needsFiscalReview: breakdownResult.needsFiscalReview,
      reasonCodes: breakdownResult.reasonCodes,
      paymentBreakdown: breakdownResult.paymentBreakdown,
    });
  });

  const report = {
    generatedAt: new Date().toISOString(),
    loanId,
    contractNumber: loan.data.contractNumber,
    customerName: loan.data.customerName,
    includeEstorno,
    dryRun,
    forceOverwriteExisting,
    movementsCount: movements.length,
    estorno: {
      generic: estornoLookup.generic,
      installments: Array.from(estornoLookup.installments).sort((a, b) => a - b),
    },
    updatedInstallmentsCount: changed.length,
    changed,
  };

  const reportPath = path.resolve('diagnostics', `recalc-${loanId}-${dryRun ? 'dry' : 'apply'}.json`);
  await fs.mkdir(path.dirname(reportPath), { recursive: true });
  await fs.writeFile(reportPath, JSON.stringify(report, null, 2), 'utf8');

  if (!dryRun && changed.length > 0) {
    await applyUpdate(idToken, loanId, updatedInstallments);
  }

  console.log(JSON.stringify({ ok: true, reportPath, ...report }, null, 2));
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
