type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) {
      obj[k] = decodeValue(v);
    }
    return obj;
  }
  return undefined;
};

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const parseArgs = () => {
  const args = new Map<string, string>();
  for (const token of process.argv.slice(2)) {
    const [key, value] = token.split('=');
    if (key?.startsWith('--') && value) args.set(key.slice(2), value);
  }
  return {
    term: (args.get('term') ?? '').trim().toLowerCase(),
  };
};

const run = async () => {
  const { term } = parseArgs();
  if (!term) {
    throw new Error('Use --term=nome');
  }

  const idToken = await getAuthToken();
  const response = await fetch(`${BASE_URL}:runQuery`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: 'loans' }],
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`runQuery failed: ${response.status} ${text}`);
  }

  const rows = (await response.json()) as Array<{ document?: { name?: string; fields?: Record<string, FirestoreValue> } }>;
  const matches: Array<Record<string, unknown>> = [];

  for (const row of rows) {
    const doc = row.document;
    if (!doc?.fields) continue;
    const fields = doc.fields;
    const customerName = String(decodeValue(fields.customerName) ?? '');
    if (!customerName.toLowerCase().includes(term)) continue;

    const docName = String(doc.name ?? '');
    const id = docName.split('/').pop() ?? '';
    const installments = decodeValue(fields.installments);
    const installmentsCount = Array.isArray(installments) ? installments.length : 0;
    matches.push({
      id,
      contractNumber: decodeValue(fields.contractNumber),
      customerName,
      amount: decodeValue(fields.amount),
      totalToReturn: decodeValue(fields.totalToReturn),
      interestRate: decodeValue(fields.interestRate),
      frequency: decodeValue(fields.frequency),
      status: decodeValue(fields.status),
      installmentsCount,
    });
  }

  console.log(JSON.stringify({ ok: true, term, matchesCount: matches.length, matches }, null, 2));
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
