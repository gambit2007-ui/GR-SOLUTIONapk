type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const round2 = (value: number): number => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) {
      obj[k] = decodeValue(v);
    }
    return obj;
  }
  return undefined;
};

const normalizeInstallmentStatus = (value: unknown): 'PAID' | 'PENDING' => {
  const normalized = String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toUpperCase();
  if (normalized === 'PAGO' || normalized === 'PAID' || normalized === 'LIQUIDADO') return 'PAID';
  return 'PENDING';
};

const installmentAmount = (inst: JsonRecord): number => {
  const amount = Number(inst.amount ?? inst.value ?? 0);
  return Number.isFinite(amount) ? round2(amount) : 0;
};

const installmentPaidAmount = (inst: JsonRecord): number => {
  const amount = Number(inst.paidAmount ?? inst.partialPaid ?? 0);
  return Number.isFinite(amount) ? round2(amount) : 0;
};

const calculateLateFee = (inst: JsonRecord): number => {
  if (normalizeInstallmentStatus(inst.status) === 'PAID') return 0;
  const baseInstallmentAmount = installmentAmount(inst);
  const dueDateRaw = String(inst.dueDate ?? '');
  if (!baseInstallmentAmount || !dueDateRaw) return 0;
  const dueDate = new Date(`${dueDateRaw}T00:00:00`);
  if (Number.isNaN(dueDate.getTime())) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (dueDate >= today) return 0;
  const diffTime = today.getTime() - dueDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  if (diffDays <= 0) return 0;
  return round2(baseInstallmentAmount * 0.015 * diffDays);
};

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const parseArgs = () => {
  const args = new Map<string, string>();
  for (const token of process.argv.slice(2)) {
    const [key, value] = token.split('=');
    if (key?.startsWith('--') && value) args.set(key.slice(2), value);
  }
  return {
    loanId: args.get('loan-id') ?? '',
  };
};

const run = async () => {
  const { loanId } = parseArgs();
  if (!loanId) throw new Error('Use --loan-id=...');
  const idToken = await getAuthToken();

  const response = await fetch(`${BASE_URL}/loans/${loanId}`, {
    headers: { Authorization: `Bearer ${idToken}` },
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan fetch failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { fields?: Record<string, FirestoreValue> };
  const fields = payload.fields ?? {};
  const decoded: JsonRecord = {};
  for (const [key, value] of Object.entries(fields)) decoded[key] = decodeValue(value);

  const installments = Array.isArray(decoded.installments) ? (decoded.installments as JsonRecord[]) : [];
  const rows = installments.map((inst, idx) => {
    const amount = installmentAmount(inst);
    const paid = installmentPaidAmount(inst);
    const lateFee = calculateLateFee(inst);
    const totalWithFee = round2(amount + lateFee);
    const remaining = round2(Math.max(totalWithFee - paid, 0));
    return {
      idx,
      number: Number(inst.number ?? idx + 1),
      dueDate: String(inst.dueDate ?? ''),
      status: String(inst.status ?? ''),
      amount,
      paid,
      lateFee,
      totalWithFee,
      remaining,
      paymentBreakdown: inst.paymentBreakdown ?? null,
    };
  });

  console.log(
    JSON.stringify(
      {
        ok: true,
        loanId,
        contractNumber: decoded.contractNumber,
        customerName: decoded.customerName,
        amount: decoded.amount,
        totalToReturn: decoded.totalToReturn,
        interestRate: decoded.interestRate,
        frequency: decoded.frequency,
        status: decoded.status,
        installmentsCount: rows.length,
        rows,
      },
      null,
      2,
    ),
  );
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
