import fs from 'node:fs/promises';
import path from 'node:path';

type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const round2 = (value: number): number => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const toNumber = (value: unknown): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const normalizeInstallmentStatus = (value: unknown): 'PAID' | 'PENDING' => {
  const normalized = String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toUpperCase();
  if (normalized === 'PAGO' || normalized === 'PAID' || normalized === 'LIQUIDADO') return 'PAID';
  return 'PENDING';
};

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) obj[k] = decodeValue(v);
    return obj;
  }
  return undefined;
};

const encodeValue = (value: unknown): FirestoreValue => {
  if (value === null || value === undefined) return { nullValue: null };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return { doubleValue: 0 };
    return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
  }
  if (typeof value === 'string') return { stringValue: value };
  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map((entry) => encodeValue(entry)) } };
  }
  if (typeof value === 'object') {
    const fields: Record<string, FirestoreValue> = {};
    for (const [k, v] of Object.entries(value as JsonRecord)) {
      if (v !== undefined) fields[k] = encodeValue(v);
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(value) };
};

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const fetchLoan = async (idToken: string, loanId: string) => {
  const response = await fetch(`${BASE_URL}/loans/${loanId}`, {
    headers: { Authorization: `Bearer ${idToken}` },
  });

  if (response.status === 404) return null;
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan fetch failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { name?: string; fields?: Record<string, FirestoreValue> };
  const fields = payload.fields ?? {};
  const decoded: JsonRecord = {};
  for (const [key, value] of Object.entries(fields)) {
    decoded[key] = decodeValue(value);
  }

  return { name: payload.name ?? '', data: decoded };
};

const applyUpdate = async (idToken: string, loanId: string, installments: unknown[]) => {
  const url = `${BASE_URL}/loans/${loanId}?updateMask.fieldPaths=installments`;
  const response = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fields: {
        installments: encodeValue(installments),
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan update failed: ${response.status} ${text}`);
  }
};

const parseArgs = () => {
  const args = new Map<string, string>();
  for (const token of process.argv.slice(2)) {
    const [key, value] = token.split('=');
    if (key?.startsWith('--') && value) args.set(key.slice(2), value);
  }
  return {
    loanId: args.get('loan-id') ?? '16Svi2UaIX5D2BSnOBMw',
    dryRun: (args.get('dry-run') ?? 'true').toLowerCase() !== 'false',
  };
};

const run = async () => {
  const { loanId, dryRun } = parseArgs();
  const idToken = await getAuthToken();
  const loan = await fetchLoan(idToken, loanId);

  if (!loan) throw new Error(`Loan not found: ${loanId}`);
  const installmentsRaw = Array.isArray(loan.data.installments) ? loan.data.installments : [];
  if (installmentsRaw.length === 0) throw new Error('Loan has no installments');

  const expectedInstallmentValue = round2(
    toNumber(loan.data.totalToReturn) / Math.max(1, installmentsRaw.length),
  );

  const updatedInstallments = installmentsRaw.map((item) =>
    typeof item === 'object' && item !== null ? { ...(item as JsonRecord) } : ({} as JsonRecord),
  );

  const changes: Array<Record<string, unknown>> = [];

  updatedInstallments.forEach((inst, index) => {
    const currentAmount = round2(toNumber(inst.amount ?? inst.value));
    const currentPaid = round2(toNumber(inst.paidAmount ?? inst.partialPaid));
    const status = normalizeInstallmentStatus(inst.status);
    const nextAmount = expectedInstallmentValue;
    const nextPaid = round2(Math.min(Math.max(currentPaid, 0), nextAmount));
    const nextStatus = status === 'PAID' ? 'PAGO' : 'PENDENTE';
    const nextPartialPaid = status === 'PAID' ? 0 : nextPaid;

    const changed =
      Math.abs(currentAmount - nextAmount) > 0.009 ||
      Math.abs(currentPaid - nextPaid) > 0.009 ||
      String(inst.status ?? '') !== nextStatus ||
      round2(toNumber(inst.partialPaid)) !== nextPartialPaid;

    if (!changed) return;

    inst.amount = nextAmount;
    inst.value = nextAmount;
    inst.paidAmount = nextPaid;
    inst.partialPaid = nextPartialPaid;
    inst.status = nextStatus;
    if (nextStatus === 'PAGO') {
      inst.lastPaidValue = nextAmount;
    }
    updatedInstallments[index] = inst;

    changes.push({
      installmentIndex: index,
      installmentNumber: inst.number ?? index + 1,
      fromAmount: currentAmount,
      toAmount: nextAmount,
      fromPaid: currentPaid,
      toPaid: nextPaid,
      fromStatus: String(inst.status ?? ''),
      toStatus: nextStatus,
    });
  });

  const report = {
    generatedAt: new Date().toISOString(),
    loanId,
    contractNumber: loan.data.contractNumber,
    customerName: loan.data.customerName,
    dryRun,
    expectedInstallmentValue,
    installmentsCount: installmentsRaw.length,
    changesCount: changes.length,
    changes,
    pendingBaseAfter: round2(
      updatedInstallments.reduce((sum, inst) => {
        if (normalizeInstallmentStatus(inst.status) === 'PAID') return sum;
        return sum + round2(toNumber(inst.amount ?? inst.value) - toNumber(inst.paidAmount ?? 0));
      }, 0),
    ),
  };

  const reportPath = path.resolve(
    'diagnostics',
    `recalc-gabriel-2026034-${loanId}-${dryRun ? 'dry' : 'apply'}.json`,
  );
  await fs.mkdir(path.dirname(reportPath), { recursive: true });
  await fs.writeFile(reportPath, JSON.stringify(report, null, 2), 'utf8');

  if (!dryRun && changes.length > 0) {
    await applyUpdate(idToken, loanId, updatedInstallments);
  }

  console.log(JSON.stringify({ ok: true, reportPath, ...report }, null, 2));
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
