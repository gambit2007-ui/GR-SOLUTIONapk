import fs from 'node:fs/promises';
import path from 'node:path';

type JsonRecord = Record<string, unknown>;

type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { timestampValue: string }
  | { stringValue: string }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { arrayValue: { values?: FirestoreValue[] } };

const API_KEY = 'AIzaSyBH1MWR7uSgcOF4WsrQnnkgPNpzdBkonxA';
const PROJECT_ID = 'grsolution-8e6cb';
const DATABASE = '(default)';
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${DATABASE}/documents`;

const round2 = (value: number): number => Number((Number.isFinite(value) ? value : 0).toFixed(2));

const getLocalISODate = (baseDate: Date = new Date()): string => {
  const date = new Date(baseDate);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const fromLegacyFrequency = (value: unknown): 'DAILY' | 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY' => {
  const normalized = String(value || '').toUpperCase();
  if (normalized === 'DAILY' || normalized === 'DIARIO') return 'DAILY';
  if (normalized === 'WEEKLY' || normalized === 'SEMANAL') return 'WEEKLY';
  if (normalized === 'BIWEEKLY' || normalized === 'QUINZENAL') return 'BIWEEKLY';
  return 'MONTHLY';
};

const buildDueDateFromOffset = (
  baseDateIso: string,
  offset: number,
  frequency: 'DAILY' | 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY',
): string => {
  const dueDate = new Date(`${baseDateIso}T12:00:00`);
  if (frequency === 'DAILY') {
    dueDate.setDate(dueDate.getDate() + offset);
  } else if (frequency === 'WEEKLY') {
    dueDate.setDate(dueDate.getDate() + (offset * 7));
  } else if (frequency === 'BIWEEKLY') {
    dueDate.setDate(dueDate.getDate() + (offset * 15));
  } else {
    dueDate.setMonth(dueDate.getMonth() + offset);
  }
  return dueDate.toISOString().split('T')[0];
};

const splitAmountEvenly = (total: number, count: number): number[] => {
  const safeCount = Math.max(0, Math.trunc(count));
  if (safeCount === 0) return [];

  const totalCents = Math.max(0, Math.round(round2(total) * 100));
  const baseCents = Math.floor(totalCents / safeCount);
  let remainder = totalCents - baseCents * safeCount;

  return Array.from({ length: safeCount }, () => {
    const valueCents = baseCents + (remainder > 0 ? 1 : 0);
    if (remainder > 0) remainder -= 1;
    return Number((valueCents / 100).toFixed(2));
  });
};

const normalizeInstallmentStatus = (value: unknown): 'PAID' | 'PENDING' => {
  const normalized = String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toUpperCase();
  if (normalized === 'PAGO' || normalized === 'PAID' || normalized === 'LIQUIDADO') return 'PAID';
  return 'PENDING';
};

const installmentAmount = (inst: JsonRecord): number => {
  const amount = Number(inst.amount ?? inst.value ?? 0);
  return Number.isFinite(amount) ? round2(amount) : 0;
};

const installmentPaidAmount = (inst: JsonRecord): number => {
  const paidAmount = Number(inst.paidAmount ?? inst.partialPaid ?? 0);
  return Number.isFinite(paidAmount) ? round2(paidAmount) : 0;
};

const calculateLateFee = (inst: JsonRecord): number => {
  if (normalizeInstallmentStatus(inst.status) === 'PAID') return 0;
  const baseInstallmentAmount = installmentAmount(inst);
  const dueDateRaw = String(inst.dueDate ?? '');
  if (!baseInstallmentAmount || !dueDateRaw) return 0;
  const dueDate = new Date(`${dueDateRaw}T00:00:00`);
  if (Number.isNaN(dueDate.getTime())) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (dueDate >= today) return 0;
  const diffTime = today.getTime() - dueDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  if (diffDays <= 0) return 0;
  return round2(baseInstallmentAmount * 0.015 * diffDays);
};

const getRemainingInstallmentValue = (inst: JsonRecord): number => {
  if (normalizeInstallmentStatus(inst.status) === 'PAID') return 0;
  const lateFee = calculateLateFee(inst);
  const totalWithFee = round2(installmentAmount(inst) + lateFee);
  const remaining = round2(totalWithFee - installmentPaidAmount(inst));
  return remaining > 0 ? remaining : 0;
};

const decodeValue = (value: FirestoreValue | undefined): unknown => {
  if (!value || typeof value !== 'object') return undefined;
  if ('nullValue' in value) return null;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return String(value.timestampValue);
  if ('stringValue' in value) return String(value.stringValue);
  if ('arrayValue' in value) return (value.arrayValue.values ?? []).map((entry) => decodeValue(entry));
  if ('mapValue' in value) {
    const fields = value.mapValue.fields ?? {};
    const obj: JsonRecord = {};
    for (const [k, v] of Object.entries(fields)) {
      obj[k] = decodeValue(v);
    }
    return obj;
  }
  return undefined;
};

const encodeValue = (value: unknown): FirestoreValue => {
  if (value === null || value === undefined) return { nullValue: null };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return { doubleValue: 0 };
    return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
  }
  if (typeof value === 'string') return { stringValue: value };
  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map((entry) => encodeValue(entry)) } };
  }
  if (typeof value === 'object') {
    const fields: Record<string, FirestoreValue> = {};
    for (const [k, v] of Object.entries(value as JsonRecord)) {
      if (v !== undefined) fields[k] = encodeValue(v);
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(value) };
};

const getAuthToken = async (): Promise<string> => {
  const email = process.env.FIREBASE_EMAIL;
  const password = process.env.FIREBASE_PASSWORD;
  if (!email || !password) throw new Error('Missing FIREBASE_EMAIL/FIREBASE_PASSWORD');

  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    },
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Auth failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { idToken?: string };
  if (!payload.idToken) throw new Error('Auth response missing idToken');
  return payload.idToken;
};

const fetchLoan = async (idToken: string, loanId: string) => {
  const response = await fetch(`${BASE_URL}/loans/${loanId}`, {
    headers: { Authorization: `Bearer ${idToken}` },
  });

  if (response.status === 404) return null;
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan fetch failed: ${response.status} ${text}`);
  }

  const payload = (await response.json()) as { name?: string; fields?: Record<string, FirestoreValue> };
  const fields = payload.fields ?? {};
  const decoded: JsonRecord = {};
  for (const [key, value] of Object.entries(fields)) {
    decoded[key] = decodeValue(value);
  }

  return { name: payload.name ?? '', data: decoded };
};

const applyUpdate = async (idToken: string, loanId: string, installments: unknown[]) => {
  const url = `${BASE_URL}/loans/${loanId}?updateMask.fieldPaths=installments`;
  const response = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fields: {
        installments: encodeValue(installments),
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Loan update failed: ${response.status} ${text}`);
  }
};

const parseArgs = () => {
  const args = new Map<string, string>();
  for (const token of process.argv.slice(2)) {
    const [key, value] = token.split('=');
    if (key?.startsWith('--') && value) args.set(key.slice(2), value);
  }
  return {
    loanId: args.get('loan-id') ?? 'SftUGR4Yc64wQrlEvmyb',
    startDate: args.get('start-date') ?? getLocalISODate(),
    dryRun: (args.get('dry-run') ?? 'true').toLowerCase() !== 'false',
  };
};

const run = async () => {
  const { loanId, startDate, dryRun } = parseArgs();
  const idToken = await getAuthToken();
  const loan = await fetchLoan(idToken, loanId);

  if (!loan) throw new Error(`Loan not found: ${loanId}`);
  const installmentsRaw = Array.isArray(loan.data.installments) ? loan.data.installments : [];
  if (installmentsRaw.length === 0) throw new Error('Loan has no installments');

  const installments = installmentsRaw.map((item) =>
    typeof item === 'object' && item !== null ? { ...(item as JsonRecord) } : ({} as JsonRecord),
  );

  const firstPendingIndex = installments.findIndex((inst) => getRemainingInstallmentValue(inst) > 0);
  if (firstPendingIndex < 0) throw new Error('No pending installments found');

  const pendingIndexes = installments.reduce<number[]>((acc, inst, index) => {
    if (index < firstPendingIndex) return acc;
    if (getRemainingInstallmentValue(inst) > 0) acc.push(index);
    return acc;
  }, []);
  if (pendingIndexes.length === 0) throw new Error('No pending installments to redistribute');

  const frequency = fromLegacyFrequency(loan.data.frequency);
  const outstandingWithLateFee = round2(
    pendingIndexes.reduce((sum, index) => sum + getRemainingInstallmentValue(installments[index]), 0),
  );
  const redistributed = splitAmountEvenly(outstandingWithLateFee, pendingIndexes.length);

  pendingIndexes.forEach((index, position) => {
    const inst = { ...installments[index] };
    const value = redistributed[position] ?? 0;
    inst.amount = value;
    inst.value = value;
    inst.paidAmount = 0;
    inst.partialPaid = 0;
    inst.lastPaidValue = undefined;
    inst.paymentDate = undefined;
    inst.paidAt = undefined;
    inst.lastPaymentDate = undefined;
    inst.paymentAmount = undefined;
    inst.paymentBreakdown = undefined;
    inst.needsFiscalReview = undefined;
    if (normalizeInstallmentStatus(inst.status) !== 'PAID') {
      inst.status = 'PENDENTE';
    }
    inst.dueDate = buildDueDateFromOffset(startDate, position, frequency);
    installments[index] = inst;
  });

  const report = {
    generatedAt: new Date().toISOString(),
    loanId,
    contractNumber: loan.data.contractNumber,
    customerName: loan.data.customerName,
    dryRun,
    startDate,
    frequency,
    firstPendingIndex,
    pendingInstallmentsCount: pendingIndexes.length,
    outstandingWithLateFee,
    redistributed,
    samplePending: pendingIndexes.slice(0, 3).map((index) => ({
      index,
      number: installments[index].number,
      dueDate: installments[index].dueDate,
      amount: installments[index].amount,
    })),
  };

  const reportPath = path.resolve(
    'diagnostics',
    `redivide-overdue-with-latefee-${loanId}-${dryRun ? 'dry' : 'apply'}.json`,
  );
  await fs.mkdir(path.dirname(reportPath), { recursive: true });
  await fs.writeFile(reportPath, JSON.stringify(report, null, 2), 'utf8');

  if (!dryRun) {
    await applyUpdate(idToken, loanId, installments);
  }

  console.log(JSON.stringify({ ok: true, reportPath, ...report }, null, 2));
};

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(JSON.stringify({ ok: false, message }, null, 2));
  process.exit(1);
});
